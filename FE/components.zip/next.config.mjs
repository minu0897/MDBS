/** 최소 dev 설정 */
export default {
  experimental: { appDir: true },
  pageExtensions: ['js','jsx','ts','tsx'],
};
